import { expect, test, type Locator } from '@playwright/test';

const products = [
  { name: 'Sauce Labs Backpack', price: '$29.99', addButton: 'add-to-cart-sauce-labs-backpack' },
  { name: 'Sauce Labs Bike Light', price: '$9.99', addButton: 'add-to-cart-sauce-labs-bike-light' },
];

function productRow(list: Locator, name: string): Locator {
  return list.locator('[data-test="inventory-item"]').filter({
    hasText: name,
  });
}

async function expectProducts(list: Locator): Promise<void> {
  const rows = list.locator('[data-test="inventory-item"]');
  await expect(rows).toHaveCount(products.length);

  for (const product of products) {
    const row = productRow(list, product.name);
    await expect(row).toHaveCount(1);
    await expect(row.locator('[data-test="inventory-item-name"]')).toHaveText(product.name);
    await expect(row.locator('[data-test="item-quantity"]')).toHaveText('1');
    await expect(row.locator('[data-test="inventory-item-price"]')).toHaveText(product.price);
  }
}

test('standard user completes checkout with the Backpack and Bike Light', async ({ browser }) => {
  const username = process.env.SAUCEDEMO_USERNAME;
  const password = process.env.SAUCEDEMO_PASSWORD;
  if (!username || !password) {
    throw new Error('Set SAUCEDEMO_USERNAME and SAUCEDEMO_PASSWORD before running this test.');
  }

  const baseURL = process.env.BASE_URL ?? 'https://www.saucedemo.com';
  const context = await browser.newContext({ baseURL });

  try {
    const page = await context.newPage();

    await test.step('Sign in and verify inventory', async () => {
      await page.goto('/');
      await page.getByRole('textbox', { name: 'Username' }).fill(username);
      await page.getByRole('textbox', { name: 'Password' }).fill(password);
      await page.getByRole('button', { name: 'Login' }).click();

      await expect(page).toHaveURL(/\/inventory\.html$/);
      await expect(page.getByText('Products', { exact: true })).toBeVisible();
    });

    await test.step('Verify inventory prices and add both products', async () => {
      const inventory = page.locator('[data-test="inventory-list"]');

      for (const product of products) {
        const row = productRow(inventory, product.name);
        await expect(row.locator('[data-test="inventory-item-name"]')).toHaveText(product.name);
        await expect(row.locator('[data-test="inventory-item-price"]')).toHaveText(product.price);
        await row.getByRole('button', { name: 'Add to cart' }).click();
      }

      await expect(page.locator('[data-test="shopping-cart-badge"]')).toHaveText('2');
    });

    await test.step('Verify cart contents and checkout information', async () => {
      await page.locator('[data-test="shopping-cart-link"]').click();
      await expectProducts(page.locator('[data-test="cart-list"]'));
      await page.getByRole('button', { name: 'Checkout' }).click();

      await page.getByRole('textbox', { name: 'First Name' }).fill('QA');
      await page.getByRole('textbox', { name: 'Last Name' }).fill('Tester');
      await page.getByRole('textbox', { name: 'Zip/Postal Code' }).fill('44000');
      await page.getByRole('button', { name: 'Continue' }).click();
    });

    await test.step('Verify order overview and totals', async () => {
      await expect(page).toHaveURL(/\/checkout-step-two\.html$/);
      await expectProducts(page.locator('[data-test="cart-list"]'));
      await expect(page.locator('[data-test="subtotal-label"]')).toHaveText('Item total: $39.98');
      await expect(page.locator('[data-test="tax-label"]')).toHaveText('Tax: $3.20');
      await expect(page.locator('[data-test="total-label"]')).toHaveText('Total: $43.18');
      await page.getByRole('button', { name: 'Finish' }).click();
    });

    await test.step('Verify completion and empty cart', async () => {
      await expect(page).toHaveURL(/\/checkout-complete\.html$/);
      await expect(page.getByRole('heading', { name: 'Thank you for your order!' })).toBeVisible();
      await expect(page.getByRole('button', { name: 'Cart, empty' })).toBeVisible();

      await page.locator('[data-test="shopping-cart-link"]').click();
      await expect(page.locator('[data-test="shopping-cart-badge"]')).toHaveCount(0);
      await expect(page.locator('[data-test="cart-list"] [data-test="inventory-item"]')).toHaveCount(0);
    });
  } finally {
    await context.close();
  }
});

test('standard user can complete checkout with an empty cart', async ({ browser }) => {
  const username = process.env.SAUCEDEMO_USERNAME;
  const password = process.env.SAUCEDEMO_PASSWORD;
  if (!username || !password) {
    throw new Error('Set SAUCEDEMO_USERNAME and SAUCEDEMO_PASSWORD before running this test.');
  }

  const baseURL = process.env.BASE_URL ?? 'https://www.saucedemo.com';
  const context = await browser.newContext({ baseURL });

  try {
    const page = await context.newPage();

    await test.step('Sign in with an empty cart', async () => {
      await page.goto('/');
      await page.getByRole('textbox', { name: 'Username' }).fill(username);
      await page.getByRole('textbox', { name: 'Password' }).fill(password);
      await page.getByRole('button', { name: 'Login' }).click();

      await expect(page).toHaveURL(/\/inventory\.html$/);
      await expect(page.getByRole('button', { name: 'Cart, empty' })).toBeVisible();
    });

    await test.step('Verify the cart has no products', async () => {
      await page.locator('[data-test="shopping-cart-link"]').click();

      await expect(page).toHaveURL(/\/cart\.html$/);
      await expect(page.locator('[data-test="shopping-cart-badge"]')).toHaveCount(0);
      await expect(page.locator('[data-test="cart-list"] [data-test="inventory-item"]')).toHaveCount(0);
    });

    await test.step('Verify empty-cart checkout requires customer information', async () => {
      await page.getByRole('button', { name: 'Checkout' }).click();
      await expect(page).toHaveURL(/\/checkout-step-one\.html$/);
      await expect(page.getByRole('button', { name: 'Cart, empty' })).toBeVisible();

      await page.getByRole('button', { name: 'Continue' }).click();
      await expect(page.getByRole('alert')).toContainText('Error: First Name is required');
      await expect(page).toHaveURL(/\/checkout-step-one\.html$/);
      await expect(page.getByRole('button', { name: 'Cart, empty' })).toBeVisible();
    });

    await test.step('Verify the empty-cart checkout overview', async () => {
      await page.getByRole('textbox', { name: 'First Name' }).fill('QA');
      await page.getByRole('textbox', { name: 'Last Name' }).fill('Tester');
      await page.getByRole('textbox', { name: 'Zip/Postal Code' }).fill('44000');
      await page.getByRole('button', { name: 'Continue' }).click();

      await expect(page).toHaveURL(/\/checkout-step-two\.html$/);
      await expect(page.locator('[data-test="cart-list"] [data-test="inventory-item"]')).toHaveCount(0);
      await expect(page.locator('[data-test="subtotal-label"]')).toHaveText('Item total: $0');
      await expect(page.locator('[data-test="tax-label"]')).toHaveText('Tax: $0.00');
      await expect(page.locator('[data-test="total-label"]')).toHaveText('Total: $0.00');
      await expect(page.getByRole('button', { name: 'Finish' })).toBeEnabled();
      await expect(page.getByRole('button', { name: 'Cart, empty' })).toBeVisible();

      await page.getByRole('button', { name: 'Finish' }).click();
      await expect(page).toHaveURL(/\/checkout-complete\.html$/);
      await expect(page.getByRole('heading', { name: 'Thank you for your order!' })).toBeVisible();
      await expect(page.getByRole('button', { name: 'Cart, empty' })).toBeVisible();

      await page.locator('[data-test="shopping-cart-link"]').click();
      await expect(page.locator('[data-test="shopping-cart-badge"]')).toHaveCount(0);
      await expect(page.locator('[data-test="cart-list"] [data-test="inventory-item"]')).toHaveCount(0);
    });
  } finally {
    await context.close();
  }
});